// Basic interactivity: responsive nav, contact form -> mailto
document.addEventListener('DOMContentLoaded', function(){
  const toggle = document.getElementById('nav-toggle');
  const nav = document.getElementById('site-nav');
  const year = document.getElementById('year');
  if (year) year.textContent = new Date().getFullYear();

  toggle && toggle.addEventListener('click', function(){
    if (nav.style.display === 'block') nav.style.display = '';
    else nav.style.display = 'block';
  });

  // contact form: open default mail client with subject/body filled
  const form = document.getElementById('contact-form');
  form && form.addEventListener('submit', function(e){
    e.preventDefault();
    const name = encodeURIComponent(document.getElementById('name').value.trim());
    const email = encodeURIComponent(document.getElementById('email').value.trim());
    const message = encodeURIComponent(document.getElementById('message').value.trim());

    const subject = encodeURIComponent(`Website contact from ${name}`);
    const body = encodeURIComponent(`Name: ${name}\nEmail: ${email}\n\nMessage:\n${message}`);

    // open mail client
    const mailto = `mailto:dr.raohamza.edu@gmail.com?subject=${subject}&body=${body}`;
    window.location.href = mailto;
  }, false);
});