# Dr Rao Hamza — Personal Website

This repository contains a lightweight, responsive personal website for Dr Rao Hamza (MBBS). It is a static site built with plain HTML/CSS/JavaScript and is optimized for easy deployment (e.g., GitHub Pages, Netlify, Vercel).

## Included files
- index.html — main page with sections: hero, about, research, experience, projects, welfare, contact
- styles.css — responsive styles and layout
- script.js — small JS for nav toggling and contact form behavior
- assets/ — place images, resume PDF, favicon here (not included in repo by default)
  - assets/Dr_Rao_Hamza_Resume.pdf (recommended filename)
  - assets/portrait.jpg (optional)

## How to use
1. Clone the repository or copy files to your project directory.
2. Put your portrait image at `assets/portrait.jpg` (optional) and your resume PDF at `assets/Dr_Rao_Hamza_Resume.pdf`.
3. Edit `index.html` to update wording, links, or to add more sections.
4. To test locally, open `index.html` in your browser.

## Deploying
- GitHub Pages:
  1. Create a new repository (e.g., `dr-rao-hamza-site`) and push all files.
  2. In repository settings → Pages, set source to `main` branch (or `gh-pages`) and root folder `/`.
  3. Site will be available at `https://<your-username>.github.io/<repo>/` after a minute.

- Netlify / Vercel:
  - Drag & drop the project folder, or connect the GitHub repo — both services will auto-detect and deploy a static site.

## Customization ideas
- Add an actual portrait image and a downloadable resume (PDF).
- Replace the mailto contact with a server-backed form or Formspree integration for message collection.
- Add Google Scholar, ORCID, ResearchGate links, or a publications page listing DOIs.
- Add analytics (Plaftorm of your choice) and SEO meta tags for keywords.
- Convert to a React/Vue static site or integrate with a static site generator (Hugo/Jekyll) if you want blog capabilities.

## Accessibility & performance
- Simple semantic HTML and a lightweight stylesheet keep load times fast.
- Labels and aria attributes included for basic accessibility.
- Keep images optimized for web (compressed JPEG/WebP).

If you'd like, I can:
- Generate an optimized SVG avatar and include it in the assets folder.
- Create a multi-page site (publications, teaching, certificates).
- Make a deploy-ready GitHub repo and push these files for you.